package com.aliucord.plugins;

import android.content.Context;

import com.aliucord.Logger;
import com.aliucord.annotations.AliucordPlugin;
import com.aliucord.entities.Plugin;
import com.aliucord.patcher.Hook;
import com.aliucord.wrappers.messages.MessageWrapper;

import com.discord.api.message.Message;
import com.discord.api.message.reaction.MessageReaction;
import com.discord.stores.StoreStream;
import com.discord.api.user.User;

import java.util.List;

/**
 * RatioPranker - Aliucord Plugin
 *
 * Watches for messages containing "ratio" (case-insensitive) from a specific user ID.
 * When found, reacts to the message with the <:prank:1333323949395677236> emoji.
 */
@AliucordPlugin
public class RatioPranker extends Plugin {

    private static final Logger logger = new Logger("RatioPranker");

    // ── CONFIG ──────────────────────────────────────────────────────────────────
    // The user ID whose "ratio" messages will get the prank reaction.
private static final long[] TARGET_USER_IDS = { 1514216138974822541, 1504413452431654952, 1515069121975288100 }; // add as many as you want

    // The custom emoji to react with: <:prank:1333323949395677236>
    private static final String REACTION_EMOJI_NAME = "prank";
    private static final long   REACTION_EMOJI_ID   = 1333323949395677236L;
    // ────────────────────────────────────────────────────────────────────────────

    @Override
    public void start(Context ctx) {

        // Hook into the MessageStore so we see every message the client receives.
        patcher.patch(
            com.discord.stores.StoreMessages.class,
            "handleMessageCreate",
            new Class[]{ Message.class },
            new Hook(callFrame -> {
                try {
                    Message message = (Message) callFrame.args[0];
                    if (message == null) return;

                    User author = message.getAuthor();
                    if (author == null) return;

                    long authorId = author.i(); // snowflake id
  boolean isTarget = false;
for (long id : TARGET_USER_IDS) {
    if (authorId == id) { isTarget = true; break; }
}
if (!isTarget) return;;

                    String content = message.getContent();
                    if (content == null) return;

                    // Check: does the message contain "ratio" anywhere?
                    if (!content.toLowerCase().contains("ratio")) return;

                    long channelId = message.getChannelId();
                    long messageId = message.getId();

                    logger.info("RatioPranker: caught ratio message " + messageId
                            + " in channel " + channelId + " — reacting...");

                    // React using Aliucord's RestAPI helper (runs off the main thread already).
                    com.aliucord.Http.Request req = new com.aliucord.Http.Request(
                        "https://discord.com/api/v9/channels/" + channelId
                        + "/messages/" + messageId
                        + "/reactions/" + REACTION_EMOJI_NAME + ":" + REACTION_EMOJI_ID + "/@me",
                        "PUT"
                    );
                    req.setHeader("Authorization", StoreStream.getAuthentication().getAuthToken());
                    req.execute();

                } catch (Throwable t) {
                    logger.error("RatioPranker error", t);
                }
            })
        );

        logger.info("RatioPranker started — watching user ID " + TARGET_USER_ID);
    }

    @Override
    public void stop(Context ctx) {
        patcher.unpatchAll();
        logger.info("RatioPranker stopped.");
    }
}
