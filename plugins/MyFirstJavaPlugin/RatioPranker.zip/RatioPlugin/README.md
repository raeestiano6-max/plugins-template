# RatioPranker – Aliucord Plugin

> Automatically reacts with <:prank:1333323949395677236> every time the target user
> sends a message containing "ratio".

---

## What it does

1. Silently watches every message that arrives in Discord.  
2. Checks whether the author's ID matches the **target user ID** you configured.  
3. Checks whether the message text contains the word **"ratio"** (case-insensitive).  
4. If both match → fires a reaction with `<:prank:1333323949395677236>` on that message.

---

## Customising the plugin (before you build)

Open `src/main/java/com/aliucord/plugins/RatioPranker.java` and find this section near the top:

```java
// ── CONFIG ──────────────────────────────────────────────────────────────────
private static final long TARGET_USER_ID = 1234L;   // <-- put the real user ID here
```

Replace `1234L` with the actual Discord user ID (right-click a user → Copy ID, Developer Mode must be on).  
The emoji ID is already set to `1333323949395677236` — only change it if the emoji moves to a different server.

---

## How to build

You need:
- **Java 11** (or Android Studio)
- The [Aliucord plugin template](https://github.com/Aliucord/plugin-template) set up

Steps:
```bash
git clone https://github.com/Aliucord/plugin-template MyPlugins
cp -r RatioPranker MyPlugins/
cd MyPlugins
./gradlew make            # Linux / Mac
gradlew.bat make          # Windows
```

The output file will be at:  
`MyPlugins/build/outputs/plugins/RatioPranker.zip`

---

## Installing on your phone (for dummies 🐣)

### Prerequisites
- Android phone with **Aliucord** already installed  
  (If you don't have it yet: https://github.com/Aliucord/Aliucord)

### Step-by-step

1. **Get the .zip file** onto your phone.  
   - Build it yourself (see above), OR  
   - Send yourself the `.zip` via Discord DM / Google Drive / USB cable.

2. **Rename it** (if needed) – the file must be called `RatioPranker.zip`.

3. **Move it** to the right folder on your phone:  
   Open your file manager → Internal Storage → `Aliucord` → `plugins`  
   Paste `RatioPranker.zip` there.  
   *(Create the `plugins` folder if it doesn't exist.)*

4. **Open Discord** (the Aliucord-patched version).

5. Go to **User Settings → Aliucord → Plugins**.  
   You should see **RatioPranker** listed. Tap the toggle to enable it.

6. **Restart Discord** (swipe it away from recent apps and reopen).

7. Done! Next time the target user sends a message with "ratio", the prank emoji will appear automatically. 🎉

---

## Troubleshooting

| Problem | Fix |
|---|---|
| Plugin doesn't appear in the list | Make sure the `.zip` is in `Aliucord/plugins/`, not a subfolder. |
| Emoji doesn't react | Confirm your account is a member of the server that owns the `prank` emoji. |
| Build fails | Ensure Java 11 is active (`java -version`) and Aliucord template is set up correctly. |

---

## Disclaimer

Use responsibly. Auto-reacting can be seen as spam and may violate Discord's ToS if abused.
